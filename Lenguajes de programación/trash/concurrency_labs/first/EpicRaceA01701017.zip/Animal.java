import java.util.Random;

public class Animal extends Thread {
  private int sleeping_low;
  private int sleeping_high;
  private int position;
  private int speed_low;
  private int speed_high;
  private int goal;
  private String name;
  private Random rand = new Random();

  public Animal(String name, int sleeping_low, int sleeping_high, int speed_low, int speed_high, int goal){
    this.sleeping_low = sleeping_low;
    this.sleeping_high = sleeping_high;
    this.speed_high = speed_high;
    this.speed_low = speed_low;
    this.position = 0;
    this.name = name;
    this.goal = goal;
  }

  public void run(){
    int speed;
    int sleep;
    while (position < goal && !isInterrupted()){
      try {
        speed = rand.nextInt(speed_high - speed_low) + speed_low;
        position = position + speed;
        System.out.printf("%s moves to position %d \n", name, position);
        if (position >= goal){
          EpicRaceMain.win(name);
        }
        if(name == "rabbit"){
          sleep = rand.nextInt(sleeping_high - sleeping_low) + sleeping_low;
          System.out.printf("%s will sleep for %d ms\n", name, sleep);
          this.sleep(sleep);
        }
      }
      catch (InterruptedException e) {
        break;
      }
    }
  }

  public void setPosition(int position){
    this.position = position;
  }

  public int getPosition(){
    return this.position;
  }

}
