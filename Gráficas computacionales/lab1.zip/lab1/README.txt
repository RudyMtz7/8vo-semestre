README.txt
 *  TC3022 - Homework 1: Learning Three.js
====================================================



1. What is your name?



Rodolfo Martínez Guevara


2. What browser and operating system did you test your program with?

Chrome + MacOS Mojave.






3. Approximately how many hours did you spend working on this assignment?


1.5 hours.




4. Describe any problems you encountered in this assignment.
 * What was hard, or what should we warn students about in the future?
 * How can I make this assignment better?

I thought the assignment was pretty straight forward. The final part in which
I have to add and animate my objects helps fully understand the concepts in the
book.






5. List any other comments (about the assignment or your submission)
 * here. Feel free to provide any feedback on what you learned from
 * doing the assignment, whether you enjoyed doing it, etc.

I enjoyed this lab, makes me eager for the next. :)
